import React, {useState} from 'react';
import './App.scss';
import ChatAlex from './components/ChatAlex/ChatAlex';
import ChatEva from './components/ChatEva/ChatEva';
import ChatModal from './components/ChatModal/ChatModal';
import './components/ChatModal/ChatModal.scss';
import ChatSend from './components/ChatSend/ChatSend';


function App () {
  const [modal, setModal] = useState(false)
  const [message, setMessage] = useState([])
  const [openCamera, setOpenCamera] = useState(false);


  const handleOpenCamera = () => {
    setOpenCamera(true);
    setModal(!modal);
  }

  const handleCloseCamera = () => {
    setOpenCamera(false);
  }
  

  return (
   <>
   <div className='App'>    
      <div className='container'> 
        <div className='allchat'>
         <ChatAlex
         handleOpenCamera = {handleOpenCamera}
         message={message}
         setMessage={setMessage} 
         />
         <ChatModal
         message={message}
         setMessage={setMessage}
        openCamera={openCamera}
        close={handleCloseCamera}
        modal={modal}
        handleCloseCamera={handleOpenCamera}
        msg={1}
        />
          <ChatEva
        handleOpenCamera = {handleOpenCamera} 
        message={message}
        setMessage={setMessage}
        />   
        </div>
      </div>
    </div>
   </> 
  );
}

export default App;
